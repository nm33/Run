const JavaScriptObfuscator = require('javascript-obfuscator');
const fs = require('fs');
const obfuscate = () => {
   fs.readFile("spam.js",'utf8', function(err, data) {
      if (err) {console.log(err)};
      let obfuscationResult = JavaScriptObfuscator.obfuscate(data);
      let uglyCode = obfuscationResult.getObfuscatedCode();
      fs.writeFile('spamx.js', uglyCode, function (err) {
         if (err) throw err;
         console.log(`sample.js has been obfuscated at ugly.js`);
      });
    })
};
obfuscate();
