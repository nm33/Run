from MIGHTAPI.MIGHTLY import LINE, OEPoll
from Naked.toolshed.shell import execute_js
import multiprocessing
from akad.ttypes import TalkException as TalkE
from multiprocessing import Process
from akad.ttypes import TalkException
import livejson, traceback, sys
app = "WIN10\t5.9.0\tSpamJS\t12"
appJS = "DESKTOPMAC\t5.11.1\tSpamJS\t12"
settings = livejson.File("settings_f.json")
proc = []
if "token" not in settings:
    settings["token"] = "#"
if "contact" not in settings:
    settings["contact"] = []
if "name" not in settings:
    settings["name"] = "@ɪɴᴠɪᴛᴇᴇ:ឆាุఐণ௫ণఐ"
exg = LINE(appName=appJS)
#try:
#    exg = LINE(settings["token"], appName=appJS)
#except:
#    exg = LINE("inviteebeta@best-mail.net","grimkung1",appName=appJS)
#settings["token"] = exg.authToken
cPoll = OEPoll(exg)
set = {"get":False,"remove":False}
def runadd(uid):
    return execute_js(f"spamadd.js uid={uid}")
def start_run(to, contacts=settings["contact"]):
    if contacts == []: return False
    try:
        client = LINE(_to=to, _client=exg, appName=appJS)
    except:
        exg.sendMessage(to, "ล็อกอินไม่สำเร็จ")
        return False
    if client.getSettings().e2eeEnable == True:
        client.sendMessage(to, "กรุณาปิด Letter Sealing ก่อนทำการรัน")
        return False
    cmd = "spam.js token={} mid={} name={}".format(client.authToken,client.profile.mid,settings["name"].strip())
    parsed_list = [c.mid for c in client.getContacts(contacts)]
    friends = client.getAllContactIds()
    for mid in parsed_list:
        if mid not in friends:
            try:
                client.findAndAddContactsByMid(mid)
            except:
                try:
                    client.sendMessage(to, "Unable to add contact. {}".format(mid))
                except TalkE as err:
                    if err.code in [7,8,20]:
                        return exg.sendMessage(to, "กรุณาล็อกอินใหม่อีกครั้ง")
                pass
        cmd+= " uid={}".format(mid)
    #is_operating = True
    execute_js(cmd)
    exg.sendMessage(to, "[@invitee:NOTIF]\nDone operation.")
    return
help = """คำสั่งทั้งหมดของ @INVITEE #Beta
@invitee:help
@invitee:contact ~ เช็คคท.
@invitee:getmode ~ เปิด/ปิดการรับคอนแทค
@invitee:removemode ~ เปิด/ปิดการลบคอนแทค
@invitee:check [เลข] ~ เช็คคท.ในรายชื่อ
@invitee:remove [เลข] ~ ลบคท.ในรายชื่อ
@invitee:setname [ชื่อที่ต้องการ] ~ เปลี่ยนชื่อห้องรัน
@invitee:login ~ ล็อกอิน
*** เมื่อลบแล้ว จะทำให้เลขคลาดเคลื่อนได้ กรุณาเช็คเลขอีกครั้ง*** """
def operator(op):
    global is_operating
    msg = op.message
    if msg.contentType not in [0,13]: return
    if msg.toType != 2: return
    if msg.contentType == 0:
        mlow = msg.text.lower()
        if mlow == "@invitee:contact":
            if settings["contact"] == []:
                return
            no = 0
            del_list = []
            for mid in settings["contact"]:
                try:
                    exg.getContact(mid)
                except:
                    del_list.append(mid)
            for d in del_list:
                settings["contact"].remove(d)
            if del_list != []:
                exg.sendMessage(msg.to, "ผู้ใช้ลบบัญชีจำนวน {} คน".format(str(len(del_list))))
            stry = "บัญชีที่รัน:\n"
            for name in [m.displayName for m in exg.getContacts(settings["contact"])]:
                no = no + 1
                stry+= "{}. {}\n".format(str(no), name)
            exg.sendMessage(msg.to, stry[:-1])
        elif mlow == "@invitee:login":
                start_run(msg.to)
        elif mlow == "@invitee:help":
            exg.sendMessage(msg.to, help)
        elif mlow.startswith("@invitee:runadd "):
            split = msg.text.split(" ")[1]
            try: split = int(split)
            except: return exg.sendMessage(msg.to, "ตัวเลขเท่านั้น")
            try:
                s = settings["contact"][split - 1]
            except:
                return exg.sendMessage(msg.to, "ไม่พบคท.ที่ต้องการจะรันแอด")
            contact = settings["contact"][split - 1]
            runadd(contact)
            exg.sendMessage(msg.to, "เรียบร้อย")
        elif mlow.startswith("@invitee:remove "):
            split = msg.text.split(" ")[1]
            try: split = int(split)
            except: return exg.sendMessage(msg.to, "ตัวเลขเท่านั้น")
            try:
                s = settings["contact"][split - 1]
            except:
                return exg.sendMessage(msg.to, "ไม่พบคท.ที่ต้องการจะลบ")
            name = exg.getContact(settings["contact"][split - 1]).displayName
            settings["contact"].remove(settings["contact"][split - 1])
            exg.sendMessage(msg.to, "ลบคท.ชื่อ {} ออกแล้ว!".format(name))
        elif mlow.startswith("@invitee:check "):
            split = msg.text.split(" ")[1]
            try: split = int(split)
            except: return exg.sendMessage(msg.to, "ตัวเลขเท่านั้น")
            try:
                s = settings["contact"][split - 1]
            except:
                return exg.sendMessage(msg.to, "ไม่พบคท.ที่ต้องการ")
            name = settings["contact"][split - 1]
            #settings["contact"].remove(settings["contact"][split - 1])
            exg.sendContact(msg.to, name)
        elif mlow.startswith("@invitee:setname "):
            name = msg.text.split(" ")[1].strip()
            if len(name) >= 50:
                exg.sendMessage(msg.to, "ชื่อห้องยาวเกินไป")
                return
            settings["name"] = name
            exg.sendMessage(msg.to, "เปลี่ยนชื่อห้องรันเป็น {} แล้ว!".format(settings["name"]))
        elif mlow == "@invitee:getmode":
            set["get"] = True if not set["get"] else False
            set["remove"] = False
            if set["get"]: exg.sendMessage(msg.to, "เปิดรับคอนแทคแล้ว!")
            else: exg.sendMessage(msg.to, "ปิดรับคอนแทคแล้ว")
        elif mlow == "@invitee:removemode":
            set["remove"] = True if not set["remove"] else False
            set["get"] = False
            if set["remove"]: exg.sendMessage(msg.to, "เปิดยกเลิกคอนแทคแล้ว")
            else: exg.sendMessage(msg.to, "ปิดยกเลิกคอนแทคแล้ว")
    if msg.contentType == 13:
        if set["get"]:
            if msg.contentMetadata["mid"] not in settings["contact"]:
                settings["contact"].append(msg.contentMetadata["mid"])
                exg.sendMessage(msg.to, "เพิ่มแล้ว")
        if set["remove"]:
            if msg.contentMetadata["mid"] in settings["contact"]:
                settings["contact"].remove(msg.contentMetadata["mid"])
                exg.sendMessage(msg.to, "ลบออกเรียบร้อยแล้ว")
def start():
    while True:
        try:
            ops = ""
            try:
                ops = cPoll.singleTrace(count=50)
            except Exception as e: print("[TRACING ERR] {}".format(e));return
            for op in ops:
                if op.type in [25,26]:
                    try: operator(op)
                    except:
                        traceback.print_exc()
                        pass
                cPoll.setRevision(op.revision)
        except Exception: traceback.print_exc();pass
        except KeyboardInterrupt:
            sys.exit(1)
if __name__ == "__main__":
    start()

